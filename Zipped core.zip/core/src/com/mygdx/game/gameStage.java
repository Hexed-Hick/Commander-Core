package com.mygdx.game;

import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.scenes.scene2d.Action;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.viewport.Viewport;

public class gameStage extends Stage{

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		super.draw();
	}

	@Override
	public void act() {
		// TODO Auto-generated method stub
		super.act();
	}

	@Override
	public void addActor(Actor actor) {
		// TODO Auto-generated method stub
		super.addActor(actor);
	}

	@Override
	public void addAction(Action action) {
		// TODO Auto-generated method stub
		super.addAction(action);
	}

	@Override
	public Array<Actor> getActors() {
		// TODO Auto-generated method stub
		return super.getActors();
	}

	@Override
	public void clear() {
		// TODO Auto-generated method stub
		super.clear();
	}

	@Override
	public Batch getBatch() {
		// TODO Auto-generated method stub
		return super.getBatch();
	}

	@Override
	public Viewport getViewport() {
		// TODO Auto-generated method stub
		return super.getViewport();
	}

	@Override
	public void setViewport(Viewport viewport) {
		// TODO Auto-generated method stub
		super.setViewport(viewport);
	}

	@Override
	public float getWidth() {
		// TODO Auto-generated method stub
		return super.getWidth();
	}

	@Override
	public float getHeight() {
		// TODO Auto-generated method stub
		return super.getHeight();
	}

	@Override
	public Camera getCamera() {
		// TODO Auto-generated method stub
		return super.getCamera();
	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub
		super.dispose();
	}
	
	
	

}
